import TrabAPI from "./TrabAPI/TrabAPI";

function App() {
  return (
    <div className="App">
      <TrabAPI />
    </div>
  );
}

export default App;
