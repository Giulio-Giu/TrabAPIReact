import React from "react";
import Characters from "./Characters/Characters";
import Episodes from "./Episodes/Episodes";
import Locations from "./Locations/Locations";

export default class TrabAPI extends React.Component {
  render() {
    return (
      <div>
        <Characters />
      </div>
    );
  }
}
